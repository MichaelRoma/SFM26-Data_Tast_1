import UIKit

let defaultValue = UserDefaults.standard

defaultValue.set(8, forKey: "Digit")
defaultValue.set(false, forKey: "LightIsOn")
defaultValue.set("iOS Trainee", forKey: "MyStatus")
defaultValue.set([6, 11, 90], forKey: "Digits")
defaultValue.set(7.904563290346863, forKey: "LongNum")

defaultValue.integer(forKey: "Digit")
defaultValue.bool(forKey: "LightIsOn")
defaultValue.string(forKey: "MyStatus")
defaultValue.array(forKey: "Digits")
defaultValue.double(forKey: "LongNum")
